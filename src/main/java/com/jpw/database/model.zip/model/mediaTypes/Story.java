package com.jpw.database.model.mediaTypes;

import com.jpw.database.model.enums.Discipline;
import com.jpw.database.model.enums.StoryType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Entity
@PrimaryKeyJoinColumn(name = "media_id")
@Getter
@NoArgsConstructor(access = lombok.AccessLevel.PROTECTED)
public class Story extends MediaBase {

    @Setter
    @Enumerated(EnumType.STRING)
    private StoryType storyType;

    public Story(UUID id, String title) {
        super(id, title, Discipline.STORY);
    }

}

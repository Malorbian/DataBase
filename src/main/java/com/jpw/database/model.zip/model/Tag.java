package com.jpw.database.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Entity
@Table(uniqueConstraints = {
        @UniqueConstraint(
                name = "uk_tag_name",
                columnNames = {"name"})
})
@Getter
@NoArgsConstructor(access = lombok.AccessLevel.PROTECTED)
public class Tag {

    @Id
    private UUID id;

    @Setter
    @Column(nullable = false)
    private String name;

    public Tag(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

}
